import * as en from './en.json';

export default {
  en,
};
